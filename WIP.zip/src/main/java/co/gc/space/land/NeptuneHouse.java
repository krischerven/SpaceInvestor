package co.gc.space.land;

public class NeptuneHouse extends House {

	public NeptuneHouse() {
		price = "20,000,000,000,000";
		arces = "50";
		propertyDetails = "High winds blowing, gases around.";
		houseFeatures = "4 bedrooms, 3 bathrooms, 1500sqft(inside a dome that's inforced)";
		architecturalStyle = "Greek Revival";
		condition = "New";
		yearBuilt = "2040";
		setHouseImage("../images/greekrevivalhouse2.jpg");
	}
}
