package co.gc.space.land;

public class EuropaHouse extends House {

	public EuropaHouse() {
		price = "900,000,000,000";
		arces = "150";
		propertyDetails = "Ice layer on top and ocean beneath(maybe)";
		houseFeatures = "4 bedrooms, 2 bathrooms, 2700sqft(inside a dome off the ground";
		architecturalStyle = "Spanish";
		condition = "New";
		yearBuilt = "2040";
		setHouseImage("../images/spanishhouse.jpg");
	}
}
