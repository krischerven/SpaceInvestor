package co.gc.space.land;

public class UmaBHouse extends House {

	public UmaBHouse() {
		price = "28,000,000,000,000";
		arces = "100";
		propertyDetails = "Earth like, nice scenary.";
		houseFeatures = "6 bedrooms, 4 bathrooms, 7400sqft";
		architecturalStyle = "Modern";
		condition = "New";
		yearBuilt = "2040";
		setHouseImage("../images/modernhouse.jpg");
	}
}
